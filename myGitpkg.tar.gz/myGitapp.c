#include <stdio.h>
int main() 
{
    printf("\n***** Hello from Github package *****\n");
    return 0;
}
